import React, { useState } from "react";
import { Phone, MapPin } from "lucide-react";
import { motion } from "framer-motion";

export default function App() {
  const [form, setForm] = useState({ name: "", phone: "", message: "" });

  const handleSubmit = (e) => {
    e.preventDefault();
    const url = `https://wa.me/919905711187?text=Name:%20${form.name}%0APhone:%20${form.phone}%0AMessage:%20${form.message}`;
    window.open(url, "_blank");
  };

  return (
    <div className="bg-gray-900 text-white min-h-screen">
      <header className="p-4 flex justify-between bg-gray-800">
        <h1>Simna Engineering</h1>
        <a href="tel:9905711187">Call Now</a>
      </header>

      <section className="text-center p-10">
        <motion.h2 initial={{opacity:0}} animate={{opacity:1}}>
          Strong Steel Solutions
        </motion.h2>
      </section>

      <section className="p-6">
        <h2 className="text-xl mb-4">Gallery</h2>
        <div className="grid grid-cols-2 gap-4">
          {[1,2,3,4].map(i => (
            <div key={i} className="bg-gray-700 h-32 flex items-center justify-center">
              Image {i}
            </div>
          ))}
        </div>
      </section>

      <section className="p-6">
        <h2 className="text-xl mb-4">Get Quote</h2>
        <form onSubmit={handleSubmit} className="space-y-2">
          <input placeholder="Name" className="w-full p-2 text-black"
            onChange={(e)=>setForm({...form,name:e.target.value})}/>
          <input placeholder="Phone" className="w-full p-2 text-black"
            onChange={(e)=>setForm({...form,phone:e.target.value})}/>
          <textarea placeholder="Work" className="w-full p-2 text-black"
            onChange={(e)=>setForm({...form,message:e.target.value})}/>
          <button type="submit" className="bg-green-500 px-4 py-2">Send</button>
        </form>
      </section>

      <footer className="p-4 text-center text-gray-400">
        <Phone /> 9905711187 | <MapPin /> Garhwa
      </footer>
    </div>
  );
}